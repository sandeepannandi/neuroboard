"use client"

import { useState, useEffect } from "react"
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd"
import { format, addDays } from "date-fns"
import {
  Calendar,
  Clock,
  Plus,
  Search,
  Edit,
  Trash2,
  MessageSquare,
  Paperclip,
  Bell,
  BellOff,
  Check,
  Download,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { ScrollArea } from "@/components/ui/scroll-area"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"

// Profile images
const profileImages = ["/images/profile1.png", "/images/profile2.png", "/images/profile3.png", "/images/profile4.png"]

// Function to get a random profile image
const getRandomProfileImage = () => {
  return profileImages[Math.floor(Math.random() * profileImages.length)]
}

// Sample data
const initialData = {
  tasks: {
    "task-1": {
      id: "task-1",
      title: "Create wireframes",
      description: "Design initial wireframes for the dashboard",
      dueDate: "2025-04-15",
      priority: "high",
      assignee: { name: "Alex Kim", avatar: "/images/profile1.png" },
      comments: [
        {
          id: "comment-1",
          author: { name: "Jamie Chen", avatar: "/images/profile2.png" },
          text: "I've started working on some ideas for this!",
          timestamp: "2025-04-08T10:30:00Z",
        },
      ],
      attachments: [
        {
          id: "attachment-1",
          name: "wireframe-draft.pdf",
          size: "2.4 MB",
          url: "#",
        },
      ],
      notifications: true,
    },
    "task-2": {
      id: "task-2",
      title: "User research",
      description: "Conduct interviews with 5 potential users",
      dueDate: "2025-04-12",
      priority: "medium",
      assignee: { name: "Jamie Chen", avatar: "/images/profile2.png" },
      comments: [],
      attachments: [],
      notifications: false,
    },
    "task-3": {
      id: "task-3",
      title: "API integration",
      description: "Connect dashboard to backend API endpoints",
      dueDate: "2025-04-20",
      priority: "high",
      assignee: { name: "Taylor Wong", avatar: "/images/profile3.png" },
      comments: [],
      attachments: [],
      notifications: true,
    },
    "task-4": {
      id: "task-4",
      title: "Documentation",
      description: "Write technical documentation for the API",
      dueDate: "2025-04-25",
      priority: "low",
      assignee: { name: "Morgan Lee", avatar: "/images/profile4.png" },
      comments: [],
      attachments: [],
      notifications: false,
    },
    "task-5": {
      id: "task-5",
      title: "QA Testing",
      description: "Test all features and document bugs",
      dueDate: "2025-04-22",
      priority: "medium",
      assignee: { name: "Casey Park", avatar: "/images/profile1.png" },
      comments: [
        {
          id: "comment-2",
          author: { name: "Alex Kim", avatar: "/images/profile2.png" },
          text: "Let's make sure we test on all browsers!",
          timestamp: "2025-04-07T14:15:00Z",
        },
      ],
      attachments: [],
      notifications: true,
    },
  },
  columns: {
    "column-1": {
      id: "column-1",
      title: "To Do",
      taskIds: ["task-1", "task-2"],
    },
    "column-2": {
      id: "column-2",
      title: "In Progress",
      taskIds: ["task-3", "task-4"],
    },
    "column-3": {
      id: "column-3",
      title: "Done",
      taskIds: ["task-5"],
    },
  },
  columnOrder: ["column-1", "column-2", "column-3"],
}

const priorityColors = {
  low: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300 border-blue-200",
  medium: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300 border-yellow-200",
  high: "bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-300 border-pink-200",
}

const columnColors = {
  "column-1": "from-pink-100 to-pink-50 dark:from-pink-950 dark:to-pink-900",
  "column-2": "from-blue-100 to-blue-50 dark:from-blue-950 dark:to-blue-900",
  "column-3": "from-green-100 to-green-50 dark:from-green-950 dark:to-green-900",
}

export default function ProjectBoard() {
  const [data, setData] = useState(initialData)
  const [searchTerm, setSearchTerm] = useState("")
  const [isAddTaskOpen, setIsAddTaskOpen] = useState(false)
  const [isEditTaskOpen, setIsEditTaskOpen] = useState(false)
  const [currentTask, setCurrentTask] = useState(null)
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    dueDate: "",
    priority: "medium",
    assignee: { name: "Unassigned", avatar: "" },
    comments: [],
    attachments: [],
    notifications: false,
  })
  const [newComment, setNewComment] = useState("")
  const [newAttachment, setNewAttachment] = useState({ name: "", size: "", url: "" })

  // Check for due date notifications
  useEffect(() => {
    const checkDueDates = () => {
      const today = new Date()
      const tomorrow = addDays(today, 1)

      Object.values(data.tasks).forEach((task) => {
        if (!task.notifications) return

        const dueDate = new Date(task.dueDate)

        // Due today
        if (
          dueDate.getDate() === today.getDate() &&
          dueDate.getMonth() === today.getMonth() &&
          dueDate.getFullYear() === today.getFullYear()
        ) {
          // Use a more direct approach to show toast
          toast({
            title: "Task Due Today! ⏰",
            description: `"${task.title}" is due today.`,
            variant: "destructive",
          })
        }

        // Due tomorrow
        else if (
          dueDate.getDate() === tomorrow.getDate() &&
          dueDate.getMonth() === tomorrow.getMonth() &&
          dueDate.getFullYear() === tomorrow.getFullYear()
        ) {
          // Use a more direct approach to show toast
          toast({
            title: "Task Due Tomorrow! 📆",
            description: `"${task.title}" is due tomorrow.`,
          })
        }
      })
    }

    // Small delay to ensure the component is fully mounted
    const timer = setTimeout(() => {
      checkDueDates()
    }, 1000)

    // Set up interval check (every 5 minutes)
    const interval = setInterval(checkDueDates, 300000) // 5 minutes

    return () => {
      clearTimeout(timer)
      clearInterval(interval)
    }
  }, [data.tasks, toast])

  const handleDragEnd = (result) => {
    const { destination, source, draggableId } = result

    // If there's no destination or if the item was dropped back in the same place
    if (!destination || (destination.droppableId === source.droppableId && destination.index === source.index)) {
      return
    }

    const sourceColumn = data.columns[source.droppableId]
    const destColumn = data.columns[destination.droppableId]

    // Moving within the same column
    if (sourceColumn.id === destColumn.id) {
      const newTaskIds = Array.from(sourceColumn.taskIds)
      newTaskIds.splice(source.index, 1)
      newTaskIds.splice(destination.index, 0, draggableId)

      const newColumn = {
        ...sourceColumn,
        taskIds: newTaskIds,
      }

      setData({
        ...data,
        columns: {
          ...data.columns,
          [newColumn.id]: newColumn,
        },
      })
      return
    }

    // Moving from one column to another
    const sourceTaskIds = Array.from(sourceColumn.taskIds)
    sourceTaskIds.splice(source.index, 1)
    const newSourceColumn = {
      ...sourceColumn,
      taskIds: sourceTaskIds,
    }

    const destTaskIds = Array.from(destColumn.taskIds)
    destTaskIds.splice(destination.index, 0, draggableId)
    const newDestColumn = {
      ...destColumn,
      taskIds: destTaskIds,
    }

    setData({
      ...data,
      columns: {
        ...data.columns,
        [newSourceColumn.id]: newSourceColumn,
        [newDestColumn.id]: newDestColumn,
      },
    })

    // Show toast notification when task is moved to Done
    if (destColumn.id === "column-3" && sourceColumn.id !== "column-3") {
      toast({
        title: "Task Completed! 🎉",
        description: `"${data.tasks[draggableId].title}" has been marked as done.`,
      })
    }
  }

  const addNewTask = () => {
    if (!newTask.title) return

    const taskId = `task-${Date.now()}`
    const randomProfileImage = getRandomProfileImage()

    const updatedTasks = {
      ...data.tasks,
      [taskId]: {
        id: taskId,
        ...newTask,
        assignee: {
          ...newTask.assignee,
          avatar: randomProfileImage,
        },
      },
    }

    const todoColumn = data.columns["column-1"]
    const updatedTodoColumn = {
      ...todoColumn,
      taskIds: [...todoColumn.taskIds, taskId],
    }

    setData({
      ...data,
      tasks: updatedTasks,
      columns: {
        ...data.columns,
        "column-1": updatedTodoColumn,
      },
    })

    setNewTask({
      title: "",
      description: "",
      dueDate: "",
      priority: "medium",
      assignee: { name: "Unassigned", avatar: "" },
      comments: [],
      attachments: [],
      notifications: false,
    })

    setIsAddTaskOpen(false)

    toast({
      title: "Task Created! 🎉",
      description: `"${newTask.title}" has been added to your board.`,
    })
  }

  const editTask = () => {
    if (!currentTask || !currentTask.title) return

    const updatedTasks = {
      ...data.tasks,
      [currentTask.id]: currentTask,
    }

    setData({
      ...data,
      tasks: updatedTasks,
    })

    setIsEditTaskOpen(false)

    toast({
      title: "Task Updated!",
      description: `"${currentTask.title}" has been updated.`,
    })
  }

  const deleteTask = (taskId) => {
    // Find which column contains this task
    const columnId = Object.keys(data.columns).find((colId) => data.columns[colId].taskIds.includes(taskId))

    if (!columnId) return

    const column = data.columns[columnId]
    const taskTitle = data.tasks[taskId].title

    // Create new taskIds array without the deleted task
    const newTaskIds = column.taskIds.filter((id) => id !== taskId)

    // Create new tasks object without the deleted task
    const { [taskId]: deletedTask, ...remainingTasks } = data.tasks

    setData({
      ...data,
      tasks: remainingTasks,
      columns: {
        ...data.columns,
        [columnId]: {
          ...column,
          taskIds: newTaskIds,
        },
      },
    })

    toast({
      title: "Task Deleted",
      description: `"${taskTitle}" has been removed.`,
    })
  }

  const addComment = (taskId) => {
    if (!newComment.trim()) return

    const task = data.tasks[taskId]
    const randomProfileImage = getRandomProfileImage()

    const comment = {
      id: `comment-${Date.now()}`,
      author: {
        name: "You",
        avatar: randomProfileImage,
      },
      text: newComment,
      timestamp: new Date().toISOString(),
    }

    const updatedTask = {
      ...task,
      comments: [...task.comments, comment],
    }

    setData({
      ...data,
      tasks: {
        ...data.tasks,
        [taskId]: updatedTask,
      },
    })

    setNewComment("")

    toast({
      title: "Comment Added ✍️",
      description: "Your comment has been added to the task.",
    })
  }

  const addAttachment = (taskId) => {
    if (!newAttachment.name) return

    const task = data.tasks[taskId]
    const attachment = {
      id: `attachment-${Date.now()}`,
      ...newAttachment,
    }

    const updatedTask = {
      ...task,
      attachments: [...task.attachments, attachment],
    }

    setData({
      ...data,
      tasks: {
        ...data.tasks,
        [taskId]: updatedTask,
      },
    })

    setNewAttachment({ name: "", size: "", url: "" })

    toast({
      title: "Attachment Added",
      description: `"${newAttachment.name}" has been attached to the task.`,
    })
  }

  const toggleNotifications = (taskId) => {
    const task = data.tasks[taskId]

    const updatedTask = {
      ...task,
      notifications: !task.notifications,
    }

    setData({
      ...data,
      tasks: {
        ...data.tasks,
        [taskId]: updatedTask,
      },
    })

    toast({
      title: updatedTask.notifications ? "Notifications Enabled" : "Notifications Disabled",
      description: updatedTask.notifications
        ? "You will receive reminders about this task."
        : "You will no longer receive reminders about this task.",
    })
  }

  const filteredData = {
    ...data,
    columns: Object.fromEntries(
      Object.entries(data.columns).map(([columnId, column]) => [
        columnId,
        {
          ...column,
          taskIds: column.taskIds.filter(
            (taskId) =>
              data.tasks[taskId].title.toLowerCase().includes(searchTerm.toLowerCase()) ||
              data.tasks[taskId].description.toLowerCase().includes(searchTerm.toLowerCase()),
          ),
        },
      ]),
    ),
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-blue-50 dark:from-pink-950 dark:to-blue-950">
      <div className="container mx-auto py-6">
        <div className="flex flex-col space-y-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-3xl font-black tracking-tight text-black dark:text-white">Flowline</h1>
              </div>
              <p className="text-muted-foreground">Organize your thoughts, tasks, and deadlines</p>
            </div>
            <div className="flex items-center gap-2 w-full md:w-auto">
              <div className="relative w-full md:w-64">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search tasks..."
                  className="w-full pl-8 border-2 border-pink-200 dark:border-pink-800 focus-visible:ring-pink-500"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Dialog open={isAddTaskOpen} onOpenChange={setIsAddTaskOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-pink-500 hover:bg-pink-600 text-white border-none">
                    <Plus className="mr-2 h-4 w-4" />
                    Add Task
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px] border-4 border-black rounded-xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
                  <DialogHeader>
                    <DialogTitle className="text-2xl font-black">Add New Task</DialogTitle>
                    <DialogDescription>Create a new task for your project.</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                      <Label htmlFor="title" className="font-bold">
                        Title
                      </Label>
                      <Input
                        id="title"
                        value={newTask.title}
                        onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                        className="border-2 border-gray-300"
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="description" className="font-bold">
                        Description
                      </Label>
                      <Textarea
                        id="description"
                        value={newTask.description}
                        onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                        className="border-2 border-gray-300"
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="dueDate" className="font-bold">
                        Due Date
                      </Label>
                      <Input
                        id="dueDate"
                        type="date"
                        value={newTask.dueDate}
                        onChange={(e) => setNewTask({ ...newTask, dueDate: e.target.value })}
                        className="border-2 border-gray-300"
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="priority" className="font-bold">
                        Priority
                      </Label>
                      <Select
                        value={newTask.priority}
                        onValueChange={(value) => setNewTask({ ...newTask, priority: value })}
                      >
                        <SelectTrigger className="border-2 border-gray-300">
                          <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="notifications"
                        checked={newTask.notifications}
                        onChange={(e) => setNewTask({ ...newTask, notifications: e.target.checked })}
                        className="h-4 w-4 rounded border-gray-300 text-pink-600 focus:ring-pink-500"
                      />
                      <Label htmlFor="notifications" className="font-bold">
                        Enable due date notifications
                      </Label>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      variant="outline"
                      onClick={() => setIsAddTaskOpen(false)}
                      className="border-2 border-gray-300"
                    >
                      Cancel
                    </Button>
                    <Button onClick={addNewTask} className="bg-pink-500 hover:bg-pink-600 text-white border-none">
                      Create Task
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <Tabs defaultValue="board" className="w-full">
            <TabsList className="mb-4 p-1 bg-white dark:bg-gray-800 border-2 border-black rounded-xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              <TabsTrigger
                value="board"
                className="data-[state=active]:bg-pink-500 data-[state=active]:text-white rounded-lg"
              >
                Board View
              </TabsTrigger>
              <TabsTrigger
                value="list"
                className="data-[state=active]:bg-pink-500 data-[state=active]:text-white rounded-lg"
              >
                List View
              </TabsTrigger>
            </TabsList>

            <TabsContent value="board" className="w-full">
              <DragDropContext onDragEnd={handleDragEnd}>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {filteredData.columnOrder.map((columnId) => {
                    const column = filteredData.columns[columnId]

                    return (
                      <div key={columnId} className="flex flex-col">
                        <div className="mb-3 flex items-center justify-between">
                          <h3 className="font-black text-lg">{column.title}</h3>
                          <Badge variant="outline" className="border-2 border-black font-bold">
                            {column.taskIds.length}
                          </Badge>
                        </div>
                        <Droppable droppableId={columnId}>
                          {(provided) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.droppableProps}
                              className={`flex-1 bg-gradient-to-b ${columnColors[columnId]} rounded-xl p-3 min-h-[500px] border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]`}
                            >
                              {column.taskIds.map((taskId, index) => {
                                const task = data.tasks[taskId]
                                return (
                                  <Draggable key={taskId} draggableId={taskId} index={index}>
                                    {(provided) => (
                                      <Card
                                        ref={provided.innerRef}
                                        {...provided.draggableProps}
                                        {...provided.dragHandleProps}
                                        className="mb-3 border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] bg-white dark:bg-gray-800"
                                      >
                                        <CardHeader className="p-4 pb-2">
                                          <div className="flex justify-between items-start">
                                            <CardTitle className="text-base font-black">{task.title}</CardTitle>
                                            <div className="flex space-x-1">
                                              <Button
                                                variant="ghost"
                                                size="icon"
                                                className="h-8 w-8 text-gray-500 hover:text-pink-500"
                                                onClick={() => {
                                                  setCurrentTask(task)
                                                  setIsEditTaskOpen(true)
                                                }}
                                              >
                                                <Edit className="h-4 w-4" />
                                                <span className="sr-only">Edit</span>
                                              </Button>
                                              <Button
                                                variant="ghost"
                                                size="icon"
                                                className="h-8 w-8 text-gray-500 hover:text-pink-500"
                                                onClick={() => deleteTask(task.id)}
                                              >
                                                <Trash2 className="h-4 w-4" />
                                                <span className="sr-only">Delete</span>
                                              </Button>
                                              <Button
                                                variant="ghost"
                                                size="icon"
                                                className="h-8 w-8 text-gray-500 hover:text-pink-500"
                                                onClick={() => toggleNotifications(task.id)}
                                              >
                                                {task.notifications ? (
                                                  <Bell className="h-4 w-4" />
                                                ) : (
                                                  <BellOff className="h-4 w-4" />
                                                )}
                                                <span className="sr-only">
                                                  {task.notifications
                                                    ? "Disable notifications"
                                                    : "Enable notifications"}
                                                </span>
                                              </Button>
                                            </div>
                                          </div>
                                          <CardDescription className="line-clamp-2">{task.description}</CardDescription>
                                        </CardHeader>
                                        <CardContent className="p-4 pt-0">
                                          <div className="flex items-center text-sm text-muted-foreground">
                                            <Calendar className="mr-1 h-3.5 w-3.5" />
                                            <span>
                                              {task.dueDate
                                                ? format(new Date(task.dueDate), "MMM d, yyyy")
                                                : "No deadline"}
                                            </span>
                                          </div>

                                          {/* Comments and Attachments Summary */}
                                          <div className="flex mt-2 space-x-4 text-xs text-muted-foreground">
                                            {task.comments.length > 0 && (
                                              <div className="flex items-center">
                                                <MessageSquare className="mr-1 h-3.5 w-3.5" />
                                                <span>{task.comments.length}</span>
                                              </div>
                                            )}
                                            {task.attachments.length > 0 && (
                                              <div className="flex items-center">
                                                <Paperclip className="mr-1 h-3.5 w-3.5" />
                                                <span>{task.attachments.length}</span>
                                              </div>
                                            )}
                                          </div>
                                        </CardContent>
                                        <CardFooter className="p-4 pt-0 flex justify-between items-center">
                                          <Badge
                                            className={`${priorityColors[task.priority]} border-2 pointer-events-none`}
                                          >
                                            {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                                          </Badge>

                                          <Popover>
                                            <PopoverTrigger asChild>
                                              <Avatar className="h-8 w-8 border-2 border-black cursor-pointer">
                                                <AvatarImage src={task.assignee.avatar} alt={task.assignee.name} />
                                                <AvatarFallback className="bg-pink-500 text-white">
                                                  {task.assignee.name.charAt(0)}
                                                </AvatarFallback>
                                              </Avatar>
                                            </PopoverTrigger>
                                            <PopoverContent className="w-80 p-0 border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                                              <div className="p-4 border-b border-gray-200">
                                                <div className="flex items-center gap-2">
                                                  <h4 className="font-bold text-lg">Task Details</h4>
                                                </div>
                                                <p className="text-sm text-muted-foreground">
                                                  Assigned to: {task.assignee.name}
                                                </p>
                                              </div>

                                              {/* Comments Section */}
                                              <div className="p-4 border-b border-gray-200">
                                                <h5 className="font-bold mb-2 flex items-center">
                                                  <MessageSquare className="mr-2 h-4 w-4" />
                                                  Comments
                                                </h5>
                                                <ScrollArea className="h-[100px] mb-2">
                                                  {task.comments.length === 0 ? (
                                                    <p className="text-sm text-muted-foreground">No comments yet</p>
                                                  ) : (
                                                    <div className="space-y-2">
                                                      {task.comments.map((comment) => (
                                                        <div key={comment.id} className="flex items-start space-x-2">
                                                          <Avatar className="h-6 w-6">
                                                            <AvatarImage
                                                              src={comment.author.avatar}
                                                              alt={comment.author.name}
                                                            />
                                                            <AvatarFallback className="bg-pink-500 text-white">
                                                              {comment.author.name.charAt(0)}
                                                            </AvatarFallback>
                                                          </Avatar>
                                                          <div>
                                                            <div className="flex items-center">
                                                              <span className="text-xs font-semibold">
                                                                {comment.author.name}
                                                              </span>
                                                              <span className="text-xs text-muted-foreground ml-2">
                                                                {format(new Date(comment.timestamp), "MMM d, h:mm a")}
                                                              </span>
                                                            </div>
                                                            <p className="text-sm">{comment.text}</p>
                                                          </div>
                                                        </div>
                                                      ))}
                                                    </div>
                                                  )}
                                                </ScrollArea>
                                                <div className="flex space-x-2">
                                                  <Input
                                                    placeholder="Add a comment..."
                                                    value={newComment}
                                                    onChange={(e) => setNewComment(e.target.value)}
                                                    className="text-sm border-2 border-gray-300"
                                                  />
                                                  <Button
                                                    size="sm"
                                                    onClick={() => addComment(task.id)}
                                                    className="bg-pink-500 hover:bg-pink-600 text-white"
                                                  >
                                                    <Check className="h-4 w-4" />
                                                  </Button>
                                                </div>
                                              </div>

                                              {/* Attachments Section */}
                                              <div className="p-4">
                                                <h5 className="font-bold mb-2 flex items-center">
                                                  <Paperclip className="mr-2 h-4 w-4" />
                                                  Attachments
                                                </h5>
                                                <ScrollArea className="h-[100px] mb-2">
                                                  {task.attachments.length === 0 ? (
                                                    <p className="text-sm text-muted-foreground">No attachments yet</p>
                                                  ) : (
                                                    <div className="space-y-2">
                                                      {task.attachments.map((attachment) => (
                                                        <div
                                                          key={attachment.id}
                                                          className="flex items-center justify-between"
                                                        >
                                                          <div className="flex items-center">
                                                            <Paperclip className="h-4 w-4 mr-2 text-muted-foreground" />
                                                            <span className="text-sm">{attachment.name}</span>
                                                            <span className="text-xs text-muted-foreground ml-2">
                                                              {attachment.size}
                                                            </span>
                                                          </div>
                                                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                                            <Download className="h-4 w-4" />
                                                            <span className="sr-only">Download</span>
                                                          </Button>
                                                        </div>
                                                      ))}
                                                    </div>
                                                  )}
                                                </ScrollArea>
                                                <div className="flex space-x-2">
                                                  <Input
                                                    placeholder="Attachment name"
                                                    value={newAttachment.name}
                                                    onChange={(e) =>
                                                      setNewAttachment({
                                                        ...newAttachment,
                                                        name: e.target.value,
                                                        size: "1.2 MB",
                                                        url: "#",
                                                      })
                                                    }
                                                    className="text-sm border-2 border-gray-300"
                                                  />
                                                  <Button
                                                    size="sm"
                                                    onClick={() => addAttachment(task.id)}
                                                    className="bg-pink-500 hover:bg-pink-600 text-white"
                                                  >
                                                    <Check className="h-4 w-4" />
                                                  </Button>
                                                </div>
                                              </div>
                                            </PopoverContent>
                                          </Popover>
                                        </CardFooter>
                                      </Card>
                                    )}
                                  </Draggable>
                                )
                              })}
                              {provided.placeholder}
                            </div>
                          )}
                        </Droppable>
                      </div>
                    )
                  })}
                </div>
              </DragDropContext>
            </TabsContent>

            <TabsContent value="list">
              <div className="rounded-xl border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] bg-white dark:bg-gray-800">
                <div className="grid grid-cols-12 p-4 font-bold border-b border-gray-200">
                  <div className="col-span-4">Task</div>
                  <div className="col-span-2">Due Date</div>
                  <div className="col-span-1">Priority</div>
                  <div className="col-span-1">Status</div>
                  <div className="col-span-1">Assignee</div>
                  <div className="col-span-3">Actions</div>
                </div>
                {Object.values(data.tasks)
                  .filter(
                    (task) =>
                      task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                      task.description.toLowerCase().includes(searchTerm.toLowerCase()),
                  )
                  .map((task) => {
                    // Find which column this task belongs to
                    const column = Object.values(data.columns).find((col) => col.taskIds.includes(task.id))

                    return (
                      <div key={task.id} className="grid grid-cols-12 p-4 border-b border-gray-200 items-center">
                        <div className="col-span-4">
                          <div className="font-bold">{task.title}</div>
                          <div className="text-sm text-muted-foreground line-clamp-1">{task.description}</div>
                        </div>
                        <div className="col-span-2 flex items-center text-sm">
                          <Clock className="mr-1 h-3.5 w-3.5 text-muted-foreground" />
                          <span>{task.dueDate ? format(new Date(task.dueDate), "MMM d, yyyy") : "No deadline"}</span>
                        </div>
                        <div className="col-span-1">
                          <Badge className={`${priorityColors[task.priority]} border-2 pointer-events-none`}>
                            {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                          </Badge>
                        </div>
                        <div className="col-span-1">
                          <Badge variant="outline" className="border-2 border-black font-bold">
                            {column?.title}
                          </Badge>
                        </div>
                        <div className="col-span-1">
                          <Avatar className="h-8 w-8 border-2 border-black">
                            <AvatarImage src={task.assignee.avatar} alt={task.assignee.name} />
                            <AvatarFallback className="bg-pink-500 text-white">
                              {task.assignee.name.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                        </div>
                        <div className="col-span-3 flex space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-2 border-black hover:bg-pink-100"
                            onClick={() => {
                              setCurrentTask(task)
                              setIsEditTaskOpen(true)
                            }}
                          >
                            <Edit className="mr-1 h-4 w-4" />
                            Edit
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-2 border-black hover:bg-pink-100"
                            onClick={() => deleteTask(task.id)}
                          >
                            <Trash2 className="mr-1 h-4 w-4" />
                            Delete
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-2 border-black hover:bg-pink-100"
                            onClick={() => toggleNotifications(task.id)}
                          >
                            {task.notifications ? (
                              <Bell className="mr-1 h-4 w-4" />
                            ) : (
                              <BellOff className="mr-1 h-4 w-4" />
                            )}
                            {task.notifications ? "Mute" : "Notify"}
                          </Button>
                        </div>
                      </div>
                    )
                  })}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Edit Task Dialog */}
      <Dialog open={isEditTaskOpen} onOpenChange={setIsEditTaskOpen}>
        <DialogContent className="sm:max-w-[500px] border-4 border-black rounded-xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black">Edit Task</DialogTitle>
            <DialogDescription>Update the details of this task.</DialogDescription>
          </DialogHeader>
          {currentTask && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-title" className="font-bold">
                  Title
                </Label>
                <Input
                  id="edit-title"
                  value={currentTask.title}
                  onChange={(e) => setCurrentTask({ ...currentTask, title: e.target.value })}
                  className="border-2 border-gray-300"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-description" className="font-bold">
                  Description
                </Label>
                <Textarea
                  id="edit-description"
                  value={currentTask.description}
                  onChange={(e) => setCurrentTask({ ...currentTask, description: e.target.value })}
                  className="border-2 border-gray-300"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-dueDate" className="font-bold">
                  Due Date
                </Label>
                <Input
                  id="edit-dueDate"
                  type="date"
                  value={currentTask.dueDate}
                  onChange={(e) => setCurrentTask({ ...currentTask, dueDate: e.target.value })}
                  className="border-2 border-gray-300"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-priority" className="font-bold">
                  Priority
                </Label>
                <Select
                  value={currentTask.priority}
                  onValueChange={(value) => setCurrentTask({ ...currentTask, priority: value })}
                >
                  <SelectTrigger id="edit-priority" className="border-2 border-gray-300">
                    <SelectValue placeholder="Select priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="edit-notifications"
                  checked={currentTask.notifications}
                  onChange={(e) => setCurrentTask({ ...currentTask, notifications: e.target.checked })}
                  className="h-4 w-4 rounded border-gray-300 text-pink-600 focus:ring-pink-500"
                />
                <Label htmlFor="edit-notifications" className="font-bold">
                  Enable due date notifications
                </Label>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-avatar" className="font-bold">
                  Change Profile Image
                </Label>
                <Button
                  type="button"
                  variant="outline"
                  className="border-2 border-gray-300"
                  onClick={() =>
                    setCurrentTask({
                      ...currentTask,
                      assignee: { ...currentTask.assignee, avatar: getRandomProfileImage() },
                    })
                  }
                >
                  Randomize Profile Image
                </Button>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditTaskOpen(false)} className="border-2 border-gray-300">
              Cancel
            </Button>
            <Button onClick={editTask} className="bg-pink-500 hover:bg-pink-600 text-white border-none">
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Toaster />
    </div>
  )
}
