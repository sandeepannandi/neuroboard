import ProjectBoard from "@/app/page"

export default function Page() {
  return <ProjectBoard />
}
